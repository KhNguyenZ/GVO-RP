code-parse
==========================================
Compile-time code analysis and generation
------------------------------------------
Copyright (c) 2022 Alex "Y_Less" Cole. Licensed under MPL 1.1

This include provides a handy set of macros for advanced compile-time code analysis and generation. With this, one can do things like analyse the parameter types for a function, auto-generate call specifiers, and otherwise create code-dependent macros.

